module Main where

import System.IO (hFlush, stdout)
import Parser (parsePrompt)
import FileFinder (findFiles)
import Prompt (Prompt)
import Data.Char

main :: IO ()
main = do
    -- putStrLn "Enter the folder to search in (relative path):"
    -- folder <- getLine
    putStrLn "Enter your file search prompt: "
    prompt <- getLine
    let lowerPrompt = map toLower prompt  
    case parsePrompt lowerPrompt of
        
        Left err -> putStrLn $ "Error parsing prompt: " ++ show err
        Right (folder, query) -> do
            putStrLn $ "folder is " ++ folder
            results <- findFiles folder query
            mapM_ putStrLn results

