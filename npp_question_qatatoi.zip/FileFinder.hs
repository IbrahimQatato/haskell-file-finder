module FileFinder (findFiles) where

import Prompt (Prompt(..), Condition(..), Conjunction(..))
import System.Directory (
    doesDirectoryExist, listDirectory, doesFileExist, 
    getModificationTime, canonicalizePath)
import System.FilePath ((</>))
import Data.Time.Clock (UTCTime, getCurrentTime, addUTCTime, utctDay)
import Data.Time.Calendar (toGregorian)
import Data.Time.Format (defaultTimeLocale, formatTime)
import Control.Monad (filterM)
import System.IO (hFileSize, withFile, IOMode(..))
import Data.List (isInfixOf)
import Data.Char (toLower)
import Data.Time.LocalTime (getCurrentTimeZone, utcToLocalTime, localDay)
import Data.Time.Calendar.WeekDate (toWeekDate)
import Data.Time.Calendar.Month
import Data.Time.Calendar.OrdinalDate
import Data.Time (addDays)



findFiles :: FilePath -> Prompt -> IO [FilePath]
findFiles folder (Prompt conj conditions) = do
    allContents <- listDirectoryRecursive folder
    filterM (matchesConditions conditions conj) allContents

listDirectoryRecursive :: FilePath -> IO [FilePath]
listDirectoryRecursive dir = do
    contents <- listDirectory dir
    foldl (\accIO name -> do
        acc <- accIO
        let path = dir </> name
        isDirectory <- doesDirectoryExist path
        if isDirectory
            then do
                subDirContents <- listDirectoryRecursive path
                return (acc ++ subDirContents)
            else return (acc ++ [path])
     ) (return []) contents

matchesConditions :: [Condition] -> Conjunction -> FilePath -> IO Bool
matchesConditions conditions conj file = do
    results <- mapM (matchesCondition file) conditions
    return $ if conj == And then all id results else any id results

matchesCondition :: FilePath -> Condition -> IO Bool
matchesCondition file (NameCondition pos name) = return $ case pos of
    "beginning" -> take (length name) file == name
    "starting" -> take (length name) file == name
    "containing" -> name `isInfixOf` file
    "ending" -> reverse (take (length name) (reverse file)) == name
    "named" -> file == name

matchesCondition file (DateCondition date) = do
    modTime <- getModificationTime file
    curTime <- getCurrentTime
    let (modYear, modMonth, modDay) = toGregorian $ utctDay modTime
        (curYear, curMonth, curDay) = toGregorian $ utctDay curTime
        (_, modWeek, _) = toWeekDate $ utctDay modTime
        (_, curWeek, _) = toWeekDate $ utctDay curTime
        (yearOfLastWeek, lastWeek, _ ) = toWeekDate (addDays (-7) (utctDay curTime)) 
        dayOfWeek = map toLower $ formatTime defaultTimeLocale "%A" modTime
        modMonthDate = YearMonth modYear modMonth
        curMonthDate = YearMonth curYear curMonth
        modDayDate = YearDay modYear modDay
        curDayDate = YearDay curYear curDay
        daysOfWeek = ["monday", "tuesday", "wednesday", 
            "thursday", "friday", "saturday", "sunday"]
        curDate = map toLower date
        in
        return $ case date of
            "today" -> curDayDate == modDayDate
            "yesterday" -> modDayDate == addDays (-1) curDayDate 
            "this week" -> modYear == curYear && modWeek == curWeek
            "last week" -> modYear == yearOfLastWeek && modWeek == lastWeek
            "this month" -> modMonthDate == curMonthDate
            "last month" -> modMonthDate == addMonths (-1) curMonthDate
            "this year" -> modYear == curYear
            "last year" -> modYear == curYear - 1
            _ | curDate `elem` daysOfWeek -> dayOfWeek == map toLower date
            _ -> error $ "Can't parse date expression: " ++ date
    
matchesCondition file (SizeCondition comp size unit) = do
    fileSize <- withFile file ReadMode hFileSize
    let fileSizeInBytes = convertToBytes size unit
    return $ case comp of
        "larger than " -> fileSize > fileSizeInBytes
        "smaller than " -> fileSize < fileSizeInBytes

convertToBytes :: Integer -> String -> Integer
convertToBytes size unit = case unit of
    "kb" -> size * 1024
    "mb" -> size * 1024 * 1024
    "gb" -> size * 1024 * 1024 * 1024
